/* ---------------- the current, junction by junction ----------------
   The wiring is a set of junctions joined by runs of wire and by parts. A run of wire can be travelled either way;
   each way is a "lane". Like reading a ladder diagram, a lane carries a button's colour when there is a path from
   L1, through that button (pressed or otherwise passing current), along the lane and on through a coil to L2.
   So a wire between two branches carries both branches' colours, each in its own direction, and an output fed
   both ways shows the mix. Ahead of a button that is not passing current, the wire waits in the colour that has
   reached it (plain egg from L1, or the colour of the buttons before), and wire that leads nowhere stays dark.
   Each junction passes on whatever is arriving from all the lanes feeding it: the colours of the buttons it came
   through, mixed where branches meet. A change (a button pressed or let go, a coil picking up or dropping out)
   sets off a new stream that travels along at speed V. So when one branch stops, the wire after the junction
   carries on with what the other branches are still sending, and only goes dark once the last of every stream
   feeding it has passed. */
let DIRS = [], OUTS = new Map(), INS = new Map(), REC = new Map(), PATHS = [], ALLOW = new Map(), REACH = new Map();
const recKey = r => !r ? '-' : r.ret ? `r${r.base}|${r.l0.toFixed(3)}|${r.l1.toFixed(3)}|${r.along.toFixed(1)}` : `${[...r.set].sort().join('')}|${r.from}|${isFinite(r.rd) ? r.rd.toFixed(1) : 'i'}`;
const along = (r, s) => !r ? null : r.ret ? { ret: true, base: r.base, along: r.along + s, l0: r.l0, l1: r.l1 } : { set: r.set, from: r.from, rd: r.rd + s };
/* Past a load the current is on its way back to L2 (ret): it keeps the colour it came in with (base), in proportion
   to the voltage still left: l0 where it came out of the load, shading to l1 (the voltage at the load's far end)
   over FADE. One load across L1 and L2: from all of its colour to none (the neutral's off-white); the first of two
   in series: from all of it to half. */
const colAtRec = r => !r ? null : r.ret ? mixOk(r.base, OFF_WHITE, 1 - lerp(r.l0, r.l1, clamp01(r.along / FADE))) : colourOf(r);
function mergeRecs(ins) {
  if (!ins.length) return null;
  const rs = ins.filter(r => r.ret);
  if (rs.length) { const m = rs.reduce((a, b) => b.along < a.along ? b : a); return { ret: true, base: rs.length > 1 ? blend(rs.map(r => r.base)) : rs[0].base, along: m.along, l0: m.l0, l1: m.l1 }; }
  const set = new Set(); ins.forEach(r => r.set.forEach(x => set.add(x)));
  const same = ins.every(r => [...r.set].sort().join() === [...ins[0].set].sort().join() && r.from === ins[0].from);
  return { set, from: ins[0].from, rd: same ? Math.min(...ins.map(r => r.rd)) : Infinity };
}
const EGG = () => ({ set: new Set(), from: SRC_COL, rd: Infinity });   // (straight from L1: the source's colour)
const isFeed1 = id => NET.feedV.get(id) === 1;
function addLane(e, from) {
  const d = { e, from, to: from === e.a ? e.b : e.a, delay: e.len / V, arrived: null, sent: null, sentKey: e.kind === 'part' && LOADT(e.part.t) ? '-|out' : '-' };   // (nothing sent yet: dark)
  if (e.kind === 'seg') {
    d.chain = from === e.a ? e.chain : [...e.chain].reverse(); d.li = from === e.a ? 0 : 1;
    // when the stream reaches each point along it (seconds after it enters)
    const T = from === e.a ? e.T : [...e.T].reverse();
    d.tk = T.map(x => Math.abs(x - T[0])); d.delay = d.tk[d.tk.length - 1];   // (for a stream with nothing ahead of it)
    d.dir = (from === e.a) === e.fwd ? 0 : 1; d.off = d.dir === 0 ? e.s0 : e.st.S - e.s0 - e.len;
  }
  DIRS.push(d);
  if (!OUTS.has(d.from)) OUTS.set(d.from, []); OUTS.get(d.from).push(d);
  if (!INS.has(d.to)) INS.set(d.to, []); INS.get(d.to).push(d);
}
function startRun() {
  NET = network();
  simT = 0; queue = []; seq = 0; busyUntil = 0; autoRel = {}; down = {}; coilOn = {}; TIMER = {}; SELPOS = {}; SELTURN = {};
  FED_AT = {}; COMP = null; LV = null; COND = {}; needPaint = true; PTL = new Map(); PARR = new Map(); PDARK = new Map(); phFault = '';
  LSW_T = {}; pvStartRun();   // (the process values back to where they start, and the switches they work)
  CON = {}; for (const p of parts) if (p.t === 'con' || p.t === 'mst') CON[p.id] = { t0: -1e9, closing: !!p.nc, shut: !!p.nc };
  DSC = {}; BLOWN = {}; FU1T = {}; OLTRIP = {}; MOT = {}; DSC_T = {}; OLRESET = {};   // every coil starts off
  tl = NET.nodes.map(() => [[-1e9, null]]);
  for (const p of parts) { delete p._chg; delete p._lead; delete p._sh; delete p._lv; delete p._ph; }
  // which way each button and coil is passed through (as if every button were passing current)
  findButtonDirections();
  const h = solveV(true).V, dist = new Map(), q = []; VOLT = h;
  for (const [id, v] of NET.feedV) if (v === 1) { dist.set(id, 0); q.push([0, id]); }
  while (q.length) { q.sort((a, b) => a[0] - b[0]); const [d, u] = q.shift(); if (d > dist.get(u)) continue;
    if (NET.feedV.get(u) === 0) continue;
    for (const e of NET.jadj.get(u) || []) { if (!viaL1(e)) continue; const w = e.a === u ? e.b : e.a, nd = d + e.len; if (!dist.has(w) || nd < dist.get(w)) { dist.set(w, nd); q.push([nd, w]); } } }
  DIRS = []; OUTS = new Map(); INS = new Map(); REC = new Map();
  stretchTimes();
  for (const e of NET.jedges) {
    if (e.kind === 'seg') { addLane(e, e.a); addLane(e, e.b); continue; }
    let from;
    if (isSw(e.part)) from = btnIn(e.part);
    else if (h.has(e.a) && h.has(e.b) && Math.abs(h.get(e.a) - h.get(e.b)) > 1e-9) from = h.get(e.a) > h.get(e.b) ? e.a : e.b;
    else from = (dist.get(e.a) ?? 1e9) <= (dist.get(e.b) ?? 1e9) ? e.a : e.b;
    addLane(e, from);
  }
  ltl = new Map();
  for (const e of NET.jedges) if (e.kind === 'seg') for (const n of e.chain.slice(1, -1)) ltl.set(n, [[[-1e9, null]], [[-1e9, null]]]);
  INLEAD = new Map();
  for (const d of DIRS) if (d.e.kind === 'part') { const p = d.e.part; if (!INLEAD.has(d.from)) INLEAD.set(d.from, []); INLEAD.get(d.from).push([p, d.from === p._a ? 'A' : 'B']); }
  findPaths(); findNoway(); findReach();
  checkShort(); if (shortNow) blowSoon(shortFuses(), 0);
  ALLOW = allowNow();
  for (const [id, v] of NET.feedV) if (v === 1) setRec(id, shortNow ? null : EGG(), 0);
  phaseWays(); phasesNow(0);
  updateCoils(0);
}
/* Long plain stretches of wire (no junctions or parts along them, only corners) carry the current faster in the
   middle. In a real panel a change reaches the far end of any wire almost at once, so the coil whose button was
   pressed first is in first however long its wire; here the current is slowed right down so it can be watched, so a
   long wire would otherwise keep its coil waiting for seconds and let a coil on a short wire, pressed later, get in
   first. So the current leaves a junction at normal speed, speeds up smoothly the longer the stretch, and keeps
   that speed right up to the next junction, part or bar (it never slows down before it gets there). Stretches up to 400 units keep normal speed throughout; past that the
   time hardly grows (a 3000-unit stretch takes about 1.2 s, against 6 s at normal speed). Each run of wire gets, for every point along it, the time the stream takes to get there. */
/* One plain stretch of length S. The speed rises smoothly: normal for the first V_LEAD units, then speeding up
   steadily all the way to the far end. Tf(s): time to travel
   s units from the start (past the far end it carries on at normal speed); Ti: the reverse. Streams on a stretch
   travel together like cars of a train: one that follows close behind another (a colour arriving a moment after
   another, as the branches of a mix do) keeps the same spacing behind it (see send), so a mix never pulls apart as
   the stretch speeds up. lead/out (one for each way along it): when the train's first stream set off, and when its
   last one gets out the far end. */
function stretch(S) {
  // (from V_LEAD on, the speed grows steadily with the distance travelled, 1x more every K units, a steady, gentle
  // acceleration, all the way to the far end: it never slows down before the next part. K is chosen so the stretch
  // takes the time wanted)
  const run = Math.max(0, S - V_LEAD);
  // how long it should take: as long as at normal speed up to V_SHORT, then only slowly longer, so a longer stretch
  // never gets there sooner than a shorter one, and a very long one hardly later
  const want = S <= V_SHORT ? S / V : V_SHORT / V + V_TAU * Math.log(1 + (S - V_SHORT) / (V * V_TAU));
  const timeFor = K => Math.min(S, V_LEAD) / V + (K / V) * Math.log(1 + run / K);
  let K = Infinity;
  if (S > V_SHORT) { let lo = Math.max(1e-3, run / (V_TOP - 1)), hi = 1e7; for (let k = 0; k < 60; k++) { const m = Math.sqrt(lo * hi); if (timeFor(m) > want) hi = m; else lo = m; } K = lo; }
  const top = 1 + run / K;
  const rel = s => 1 + Math.max(0, Math.min(s, S) - V_LEAD) / K;   // speed at s, as a multiple of normal
  const n = Math.ceil(S), T = new Float64Array(n + 1);
  for (let i = 1; i <= n; i++) T[i] = T[i - 1] + 1 / (V * rel(i - 0.5));
  const Tf = s => { if (s <= 0) return s / V; if (s >= n) return T[n] + (s - n) / V; const i = Math.floor(s); return T[i] + (T[i + 1] - T[i]) * (s - i); };
  const Ti = t => { if (t <= 0) return t * V; if (t >= T[n]) return n + (t - T[n]) * V; let lo = 0, hi = n; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (T[m] <= t) lo = m; else hi = m; } return lo + (t - T[lo]) / (T[hi] - T[lo]); };
  return { S, Tf, Ti, rel: s => s >= S ? 1 : rel(s), top, lead: [-Infinity, -Infinity], out: [-Infinity, -Infinity] };
}
// how long the current takes along one small step of wire, or through a part (used by the checks)
let STEP_T = new Map();
const stepTime = e => e.kind === 'part' ? e.w / V : STEP_T.get(Math.min(e.a, e.b) + ',' + Math.max(e.a, e.b)) ?? (e.w || 0) / V;
function stretchTimes() {
  STEP_T = new Map();
  const J = NET.jadj, plain = v => !NET.feedV.has(v) && (J.get(v) || []).length === 2 && J.get(v).every(e => e.kind === 'seg');
  const done = new Set();
  for (const e0 of NET.jedges) {
    if (e0.kind !== 'seg' || done.has(e0)) continue;
    // walk back to one end of the stretch, then along it to the other
    let e = e0, at = e0.a;
    for (let g = 0; g < 10000 && plain(at); g++) { const n = J.get(at).find(x => x !== e); if (n === e0) break; at = n.a === at ? n.b : n.a; e = n; }
    const runs = []; let from = at === e.a ? e.a : e.b, cur = e;
    for (let g = 0; g < 10000 && cur && !done.has(cur); g++) {
      done.add(cur); runs.push([cur, from]); const to = cur.a === from ? cur.b : cur.a;
      if (!plain(to)) break; cur = J.get(to).find(x => x !== cur); from = to;
    }
    const st = stretch(runs.reduce((t, [r]) => t + r.len, 0)), Tof = st.Tf;
    let s0 = 0;
    for (const [r, f] of runs) {
      const m = r.chain.length - 1, fwd = f === r.a;
      r.st = st; r.s0 = s0; r.fwd = fwd;
      r.T = r.chain.map((_, k) => Tof(s0 + r.len * (fwd ? k : m - k) / m));
      for (let k = 1; k <= m; k++) STEP_T.set(Math.min(r.chain[k - 1], r.chain[k]) + ',' + Math.max(r.chain[k - 1], r.chain[k]), Math.abs(r.T[k] - r.T[k - 1]));
      s0 += r.len;
    }
  }
}
/* every way from L1 to L2 that goes through at least one coil and never visits a junction twice (buttons only the
   way they pass current, coils from their L1 side). Worked out once per run; a ladder of rungs has only a few dozen. */
function findPaths() {
  PATHS = [];
  const isL1 = id => NET.feedV.get(id) === 1, isL2 = id => NET.feedV.get(id) === 0;
  // junctions from which L2 can be reached at all (so dead ends are never explored)
  const toL2 = new Set([...NET.feedV].filter(([, v]) => v === 0).map(([id]) => id)), st = [...toL2];
  while (st.length) { const v = st.pop(); for (const d of INS.get(v) || []) if (!toL2.has(d.from)) { toL2.add(d.from); st.push(d.from); } }
  let budget = 400000;
  const seen = new Set(), path = [];
  const dfs = (v, coil) => {
    if (--budget < 0) return;
    if (isL2(v)) { if (coil) PATHS.push([...path]); return; }
    for (const d of OUTS.get(v) || []) {
      const w = d.to;
      if (seen.has(w) || !toL2.has(w) || isL1(w)) continue;
      seen.add(w); path.push(d);
      dfs(w, coil || (d.e.kind === 'part' && LOADT(d.e.part.t)));
      path.pop(); seen.delete(w);
    }
  };
  for (const [id, v] of NET.feedV) if (v === 1) { seen.add(id); dfs(id, false); seen.delete(id); }
}
/* Where runs of wire form loops, a colour could otherwise come back round a loop and feed the very wire it came
   from: when it stopped, pieces of wire would stay lit, feeding one another, after the end of the current had passed.
   So within any loop a colour could go round (worked out once per run, over every path), a run of wire carries the
   colour only the way real current goes along it: from higher voltage to lower, with the circuit solved as if every
   button were passing current (see solve.js; every wire a small resistance, so current runs down each branch of a
   loop from the junction it leaves to the one it joins). Runs outside such loops are left as they are, so on a wire
   between two branches each branch's colour still runs its own way along it, and the two mix.
   NOWAY: lane -> the colours it may not carry. VOLT: junction -> voltage. */
let NOWAY = new Map(), VOLT = new Map();
function findNoway() {
  NOWAY = new Map();
  // every colour each lane can carry along some path (with the coils in or out)
  const lanes = new Map(), add = (d, k) => { if (!lanes.has(k)) lanes.set(k, new Set()); lanes.get(k).add(d); };
  for (const coilsIn of [false, true]) for (const path of PATHS) {
    let label = '';
    for (const d of path) {
      if (d.e.kind === 'part') { if (isOp(d.e.part)) label = opLabel(d.e.part, label); else if (isCon(d.e.part)) add(d, label); else if (LOADT(d.e.part.t) && coilsIn) label = 'ret'; continue; }
      add(d, label);
    }
  }
  for (const [k, ls] of lanes) {
    // the loops this colour could go round: strongly connected groups of junctions (Tarjan's method, without recursion)
    const out = new Map(); for (const d of ls) { if (!out.has(d.from)) out.set(d.from, []); out.get(d.from).push(d.to); }
    const idx = new Map(), low = new Map(), comp = new Map(), on = new Set(), stack = []; let n = 0, c = 0;
    for (const v0 of out.keys()) {
      if (idx.has(v0)) continue;
      const work = [[v0, 0]]; idx.set(v0, n); low.set(v0, n); n++; stack.push(v0); on.add(v0);
      while (work.length) {
        const top = work[work.length - 1], [v, i] = top, ws = out.get(v) || [];
        if (i < ws.length) {
          top[1]++; const w = ws[i];
          if (!idx.has(w)) { idx.set(w, n); low.set(w, n); n++; stack.push(w); on.add(w); work.push([w, 0]); }
          else if (on.has(w)) low.set(v, Math.min(low.get(v), idx.get(w)));
        } else {
          work.pop(); if (work.length) { const u = work[work.length - 1][0]; low.set(u, Math.min(low.get(u), low.get(v))); }
          if (low.get(v) === idx.get(v)) { let w; do { w = stack.pop(); on.delete(w); comp.set(w, c); } while (w !== v); c++; }
        }
      }
    }
    for (const d of ls) {
      if (d.e.kind !== 'seg' || comp.get(d.from) !== comp.get(d.to)) continue;
      const a = VOLT.get(d.from), b = VOLT.get(d.to);
      if (a === undefined || b === undefined) continue;
      const tol = 1e-12 * Math.max(1, Math.abs(a));
      if (a > b + tol) continue;   // downhill: the way current goes
      // level (no current along it, as across a balanced bridge): both ways only if the colour cannot go either way
      // along it (it would feed itself back and forth): then one way only
      if (Math.abs(a - b) <= tol && (d.from < d.to || ![...ls].some(x => x.e === d.e && x !== d))) continue;
      if (!NOWAY.has(d)) NOWAY.set(d, new Set()); NOWAY.get(d).add(k);
    }
  }
}
// the colour a lane carries past a pushbutton or a limit, temperature or pressure switch: the switch's own, except past a
// coil (a switch on the coil's way back to L2), where it is still the return current
const opLabel = (p, label) => label === 'ret' ? 'ret' : opKey(p);
const onward = (d, k) => !(NOWAY.get(d) && NOWAY.get(d).has(k));
// which colours each lane may carry right now: along every path, from L1 up to the first button not passing current,
// each lane carries the colour of the last button before it ('' for plain egg, 'ret' after a coil)
// how long the current takes from L1 to the far end of each lane along any path carrying each colour: the end of a
// colour's stream can still be on its way for that long (a button keeps sending its colour
// until the change upstream of it has reached it)
function findReach() {
  REACH = new Map();
  for (const path of PATHS) {
    let label = '', s = 0;   // (s: how long the current takes to get there, in seconds)
    for (const d of path) {
      s += d.e.kind === 'seg' ? d.delay : d.e.len / V;
      if (d.e.kind === 'part' && !isCon(d.e.part)) { if (isOp(d.e.part)) label = opLabel(d.e.part, label); else if (LOADT(d.e.part.t)) label = 'ret'; continue; }
      if (!onward(d, label)) break;   // (the colour cannot go this way: this path carries none of it on from here)
      const m = REACH.get(d) || {}; m[label] = Math.max(m[label] || 0, s); REACH.set(d, m);
    }
  }
}
const filtered = d => d.e.kind === 'seg' || isCon(d.e.part);   // lanes that only carry the colours with a path along them
function allowNow() {
  const A = new Map();
  for (const path of PATHS) {
    let label = '';
    for (const d of path) {
      if (d.e.kind === 'part') {
        if (isSw(d.e.part)) { if (!closed(d.e.part)) break; if (isOp(d.e.part)) label = opLabel(d.e.part, label); else { if (!A.has(d)) A.set(d, new Set()); A.get(d).add(label); } }   // a contact passes on the colour it is given
        else if (COND[d.e.part.id]) label = 'ret';   // past a coil with current through it: the return side, back to L2
        // (a coil that cannot pick up, because something past it is open, carries no current: the wire past it is as
        // live as the wire before it, so the colour waiting at the coil carries on up to whatever is open)
        continue;
      }
      if (!onward(d, label)) break;
      if (!A.has(d)) A.set(d, new Set()); A.get(d).add(label);
    }
  }
  return A;
}
// what of a stream a lane lets through: only the colours that have a path along it
function filt(d, r, t) {
  if (!r || !filtered(d)) return r;
  // a colour the lane can no longer carry is still let through for as long as some of it could still be on its way
  // (the end of its stream, or pulses following one another), so it runs out along the wire behind the last of it
  // rather than being cut off where it is
  const A0 = ALLOW.get(d), late = d.drain ? Object.keys(d.drain).filter(x => d.drain[x] > t + 1e-9) : [];
  const A = late.length ? new Set([...(A0 || []), ...late]) : A0;
  if (!A) return null;
  if (r.ret) return A.has('ret') ? r : null;
  if (!r.set.size) return A.has('') ? r : null;
  const s = [...r.set].filter(x => A.has(x));
  return !s.length ? null : s.length === r.set.size ? r : { set: new Set(s), from: r.from, rd: r.rd };
}
const active = d => d.e.kind === 'seg' ? ALLOW.has(d) : isSw(d.e.part) ? closed(d.e.part) || !!d.draining : true;   // (a coil always passes something on, or nothing: see through)
// what a run hands on at its far end, given what entered it
function through(d, r) {
  if (!r) return null;
  if (d.e.kind === 'seg') return along(r, d.e.len);
  // a switch past a coil (on its way back to L2) carries the return current through as it is, as a contact does: only
  // current still on its way from L1 takes on a button's colour
  if (isOp(d.e.part)) return r.ret ? along(r, d.e.len) : { set: new Set([opKey(d.e.part)]), from: colourOf(r), rd: 0 };
  if (isCon(d.e.part)) return along(r, d.e.len);   // a relay contact passes the current on as it is
  // through a coil that is in: the return side, fading to egg. Through a coil that cannot pick up: the colour
  // waiting at it, on up to whatever is open past it
  if (COND[d.e.part.id]) return { ret: true, base: r.ret ? r.base : colourOf(r), along: 0, l0: lv(d.e.part)[0], l1: lv(d.e.part)[1] };
  if (r.ret) return null;
  return fedNow(d.from) ? along(r, d.e.len) : null;   // (the end of a broken stream stops at the coil)
}
// send a stream into run d starting now: the points along it change one after another as it travels
function send(d, r, t, atOnce) {
  r = filt(d, r, t);
  if (d.draining && !(r && r.ret)) { d.draining = false; if (!closed(d.e.part)) r = null; }   // the end of the return current has gone through; the switch is open
  const key = recKey(r) + (d.e.kind === 'part' && LOADT(d.e.part.t) ? (COND[d.e.part.id] ? `|in${lv(d.e.part).join('|')}` : '|out') : '');
  if (d.sent !== undefined && d.sentKey === key) return;
  d.sent = r; d.sentKey = key;
  const out = through(d, r);
  if (d.e.kind !== 'seg') {
    // the part's leads: the current flows in from the end it enters at, and out along the far lead just in time to
    // reach the far end when it arrives there
    const p = d.e.part, outS = d.from === p._a ? 'B' : 'A', Ls = TERM(p) - (p.t === 'tsw' ? TSW_HALF : BODYH(p.t) / 2);
    const tOut = t + (atOnce ? 0 : d.delay);
    leadEvent(p, outS, tOut - Ls / V, out, 'body');
    schedule(tOut, () => { d.arrived = out; reeval(d.to, evT); });
    return;
  }
  const m = d.chain.length - 1, st = d.e.st, w = d.dir;
  // where this stream sits in its stretch's train: a set distance (dd) behind the train's first stream. Carried on
  // from the run before when the stream has just come along the same stretch; otherwise it joins the train already
  // on the stretch only if it is close enough behind that the train is still at (nearly) normal speed where it is,
  // so it never lurches forward as it joins; any further behind and it leads a new train of its own
  let tl, dd;
  if (CARRY && CARRY.st === st && CARRY.w === w) ({ tl, dd } = CARRY);
  else {
    tl = st.lead[w];
    dd = t < st.out[w] ? st.Ti(t - tl) - d.off : Infinity;
    if (!(dd >= -1e-6 && d.off + dd < st.S / 2 && st.rel(d.off + dd) <= 1.15)) { tl = t - st.Tf(d.off); dd = 0; st.lead[w] = tl; }
    dd = Math.max(0, dd);
  }
  const at = s => tl + st.Tf(d.off + s + dd);
  for (let k = 1; k < m; k++) { const s = d.e.len * k / m; setAt(d.chain[k], Math.max(t, at(s)), colAtRec(along(r, s)), d.li); }
  const tEnd = Math.max(t, at(d.e.len));
  st.out[w] = Math.max(st.out[w], tl + st.Tf(st.S + dd));
  const carry = { st, w, tl, dd };
  schedule(tEnd, () => { d.arrived = out; const was = CARRY; CARRY = carry; try { reeval(d.to, evT); } finally { CARRY = was; } });
}
let CARRY = null;   // the train a stream arriving at a corner belongs to, while it is passed on along the stretch
// a lead's latest changes (what it shows, from when, flowing from the part's end or from its body)
function leadEvent(p, S, t0, rec, from) { const L = (p._lead || (p._lead = { A: [], B: [] }))[S]; L.push({ t0, col: colAtRec(rec), from }); if (L.length > 6) L.shift(); }
let INLEAD = new Map();   // junction -> the part leads current flows in along from there
function setRec(v, r, t) {
  if (recKey(REC.get(v)) === recKey(r)) return;
  REC.set(v, r);
  for (const [p, S] of INLEAD.get(v) || []) leadEvent(p, S, t, r, 'term');   // what reaches a part flows in along its lead
  setAt(v, t, colAtRec(r));
  for (const d of OUTS.get(v) || []) if (d.e.kind === 'seg' || active(d)) send(d, r, t);
  if (coilIns.has(v)) updateCoils(t);
}
function reeval(v, t) {
  if (isFeed1(v)) return;
  setRec(v, mergeRecs((INS.get(v) || []).filter(d => d.arrived).map(d => d.arrived)), t);
}
// what is joined to what right now, through wires and closed switches (worked out again whenever a switch moves)
let COMP = null;
const compNow = () => COMP || (COMP = components(NET, conducts));
// is junction v joined to L1 right now (so what has reached it is still fed, not the end of a broken stream)?
// the voltages right now (see loadShares in solve.js): worked out again whenever a switch moves
let LV = null, COND = {};   // (COND: the loads with current through them)
const sharesNow = () => LV || (LV = loadShares(compNow()));
const lv = p => p._lv || [1, 0];   // (the voltage at a load's two ends while current goes through it)
const shareOf = p => sharesNow().share.get(p.id) || 0;
const levelAt = v => sharesNow().V.get(compNow()(v)) ?? 0;
// is junction v joined on to L2 right now, through wires, closed switches and loads other than p?
function onToL2(p, v) {
  const S = sharesNow(), f = compNow(), seen = new Set([f(v)]), st = [f(v)];
  while (st.length) { const u = st.pop(); if (u === S.c2) return true; for (const [w, , id] of S.adj.get(u) || []) if (id !== p.id && !seen.has(w)) { seen.add(w); st.push(w); } }
  return false;
}
const fedNow = v => { const f = compNow(); return f(v) === f(NET.L1); };
/* Which coil was first: when the path from L1 through a coil to L2 is completed (a button pressed), the time is noted.
   In a real panel current is there at once, so the coil whose path was completed first is in first, and its contacts
   act first. Here current takes time to travel, so a coil whose current arrives sooner (a shorter wire) waits rather
   than pick up ahead of a coil that was first, if picking up would cut that coil off (an interlock). */
let FED_AT = {};
const fedBy = (f, c) => { const a = f(c._a), b = f(c._b), l1 = f(NET.L1), l2 = f(NET.L2); return (a === l1 && b === l2) || (a === l2 && b === l1); };
function wouldCutOff(x, f0) {
  // with x in (its contacts moved), would any coil that was first and whose current is on its way lose its path?
  // (a coil that was first counts until its own contacts have finished moving: its current still on its way, or just in)
  const settling = c => !coilOn[c.id] || simT < (c._chg ?? -1e9) + CT + SWING + 1e-6;
  const others = parts.filter(c => c.t === 'coil' && c !== x && settling(c) && FED_AT[c.id] !== undefined && FED_AT[c.id] < FED_AT[x.id] - 1e-9 && fedBy(f0, c));
  if (!others.length) return false;
  // (an on-delay timer's timed contacts stay as they are as it picks up; only its instantaneous ones change)
  const flips = c => c.t === 'con' && c.L === x.L && (!isTimer(x) || c.inst || x.tof);   // (an off-delay timer's timed contacts change at once too)
  if (isTimer(x) && !parts.some(flips)) return false;
  const alt = e => e.kind === 'w' || (isSw(e.part) && (flips(e.part) ? !e.part.nc : closed(e.part)));
  const f1 = components(NET, alt);
  return others.some(c => !fedBy(f1, c));
}
// a coil picks up when current reaches it and it has a way through to L2; it drops out when its current is gone
let coilIns = new Set();
function updateCoils(t) {
  const f = compNow();
  coilIns = new Set(); let changed = false;
  for (const p of parts) if (LOADT(p.t)) { if (fedBy(f, p)) { if (FED_AT[p.id] === undefined) FED_AT[p.id] = t; } else delete FED_AT[p.id]; }
  for (const p of parts) if (LOADT(p.t)) {   // (a pilot light lights just as a coil picks up)
    const d = DIRS.find(x => x.e.part === p); if (!d) continue;
    coilIns.add(d.from);
    p._inS = d.from === p._a ? 'A' : 'B';   // (the end its current comes in at)
    const r = REC.get(d.from);
    // current goes through a load once it has reached it, with the circuit through it complete right now: from L1,
    // through it (and anything in series with it) to L2. (Never from the end of a stream that has been cut off.)
    // A coil picks up with enough of the voltage across it (see loadShares), and not ahead of a coil that was first
    // and that it would cut off; a pilot light lights with whatever share it gets
    // (its supply cut off on the way to it: it carries on, as it was, until the last of its current has reached it)
    let sh = shareOf(p), cond = !shortNow && !!r && sh > 1e-9;
    if (!cond && !shortNow && !!r && COND[p.id] && onToL2(p, d.to)) { cond = true; sh = p._sh ?? 1; }
    else if (cond) { p._sh = sh; p._lv = [levelAt(d.from), levelAt(d.to)]; }
    const pf = p.t === 'xfm' && phFedAt(p, t);
    if (pf) { cond = true; sh = 1; }
    const pull = p.t === 'lamp' || p.t === 'xfm' || sh >= PULL_IN * ratedShare(p) - 1e-9;   // (a light lights, and a transformer works, on whatever it gets)
    if (cond && !COND[p.id] && pull && p.t === 'coil' && wouldCutOff(p, f)) cond = false;
    const want = cond && pull, wasC = !!COND[p.id];
    let atOnce = false; const wasOn = !!coilOn[p.id];
    if (want !== wasOn) {
      coilOn[p.id] = want; p._chg = t;
      if (p.t === 'xfm') { if (want && pf) p._ph = { a: PH_COL[phaseOfAt(p._a, t) - 1], b: PH_COL[phaseOfAt(p._b, t) - 1], t0: t }; else if (want) delete p._ph; else if (p._ph) p._ph.off = t; }
      const moveAll = at => { for (const c of parts) if ((c.t === 'con' || c.t === 'mst') && c.L === p.L) schedule(at + CT, () => moveContact(c, evT)); };
      if (isTimer(p)) {
        // its instantaneous contacts follow it at once; its timed ones as its type says (see sim-core). Every contact of
        // its letter is looked at whenever anything changes, and works out for itself whether it has anything to do
        const was = TIMER[p.id] || { act: false }, fresh = (timing, act) => ({ real: timersReal, counted: 0, base: 0, t0: t, out: false, timing, act });
        let st;
        if (!p.tof) st = want ? fresh(true, false) : fresh(false, false);   // on-delay: times while energized; resets when not
        else if (want) st = fresh(false, true);                              // off-delay: changes over at once
        else st = fresh(was.act, was.act);                                   // and times once power is lost
        st.onOut = at => { st.act = !p.tof; moveAll(at); };
        TIMER[p.id] = st; armTimer(p, st);
        moveAll(t);
      } else if (p.t === 'coil') for (const c of parts) if ((c.t === 'con' || c.t === 'mst') && c.L === p.L) schedule(t + CT, () => moveContact(c, evT));
      // a transformer: its secondary comes alive (or goes dead) with its primary
      if (p.t === 'xfm' && p._sw) { const sw = p._sw; schedule(t, () => switched(sw, evT)); }   // its contacts follow
    }
    // current already at the load, and its way back to L2 opening or closing: the change starts at its far end at
    // once (rather than travelling through it like new current)
    if (cond !== wasC) atOnce = !!r && p._inKey === recKey(r);
    COND[p.id] = cond;
    p._inKey = recKey(r || null);
    if (want !== wasOn || cond !== wasC) changed = true;
    send(d, r || null, t, atOnce);   // keep what goes through it up to date
  }
  if (changed) refreshAllow(t);   // a coil picking up or dropping out changes what the wire past it may carry
}
function checkShort() { const f = components(NET, conducts); shortNow = f(NET.L1) === f(NET.L2); }
const allowKey = A => A ? [...A].sort().join() : '';
// turn selector switch L to position pos (every drawing of it turns together; its knob turns over a moment)
function turn(L, pos) {
  const m = mainSel(L); if (!m) return;
  const from = selPos(L); pos = Math.max(0, Math.min(selN(m) - 1, pos));
  if (pos === from) return;
  SELTURN[L] = { from, to: pos, t0: simT }; SELPOS[L] = pos;
  needPaint = true; if (simT + SEL_TURN > busyUntil) busyUntil = simT + SEL_TURN;
  switched(parts.filter(p => p.t === 'sel' && p.L === L), simT);
}
function press(L, v) {
  if (!!down[L] === v) return;
  down[L] = v; needPaint = true;
  if (parts.some(p => isLim(p) && opKey(p) === L)) { LSW_T[L] = simT; if (simT + LSW_MOVE > busyUntil) busyUntil = simT + LSW_MOVE; }   // (a limit switch: it moves over a moment)
  switched(parts.filter(p => (p.t === 'btn' && p.L === L) || (isLim(p) && opKey(p) === L)), simT);   // (a pushbutton's letter, or a limit or temperature switch's key)
}
// a relay contact's bar starts to move: it stops passing current as soon as it lifts, and passes current again
// only once it has landed
function moveContact(c, t) {
  const want = conActuated(c) !== !!c.nc, s = CON[c.id];
  if (!s || s.closing === want) return;
  CON[c.id] = { t0: t, closing: want, shut: s.shut };
  if (t + SWING > busyUntil) busyUntil = t + SWING;
  const sw = c.t === 'mst' ? c._poles : [c];   // (a starter: its three poles)
  if (want) schedule(t + SWING, () => { const k = CON[c.id]; if (k.closing && !k.shut) { k.shut = true; switched(sw, evT); } });
  else if (s.shut) { CON[c.id].shut = false; switched(sw, t); }
}
// some pushbuttons or contacts have just opened or closed
function switched(sw, t) {
  COMP = null; LV = null;
  const was = shortNow;
  checkShort(); if (shortNow) blowSoon(shortFuses(), t);
  if (was !== shortNow) for (const [id, fv] of NET.feedV) if (fv === 1) setRec(id, shortNow ? null : EGG(), t);
  for (const d of DIRS) if (d.e.kind === 'part' && sw.includes(d.e.part)) {
    const r = REC.get(d.from) || null;
    // a switch on the return side (past a coil) that opens stops the coil, and the return current already past the
    // coil runs out through it to L2 behind its own end, rather than being cut where the switch is
    d.draining = !closed(d.e.part) && !!r && !!r.ret;
    if (!d.draining) send(d, closed(d.e.part) ? r : null, t);
  }
  // coils first: a contact closing behind a coil lets the coil pick up, and then only its return current (not the
  // colour that was waiting in front of the contact) goes on past the contact
  phasesNow(t);
  updateCoils(t);
  refreshAllow(t);
}
/* which colours each lane may carry, worked out again after a change. Lanes that can now carry a colour they could
   not before pick up what their junction already has. (A lane that loses a colour keeps carrying it until that
   colour's own stream runs out, so it fades along the wire, from where it stopped, rather than vanishing.) */
function refreshAllow(t) {
  const old = ALLOW; ALLOW = allowNow();
  for (const d of DIRS) if (filtered(d)) {
    const a = old.get(d), b = ALLOW.get(d);
    if (a) for (const x of a) if (!b || !b.has(x)) (d.drain || (d.drain = {}))[x] = t + ((REACH.get(d) || {})[x] || 0) + 0.3;
    if (b && [...b].some(x => !a || !a.has(x))) send(d, REC.get(d.from) || null, t);
  }
}

/* ---------------- three-phase power ----------------
   Kept apart from the current between L1 and L2: each phase box's phase spreads out from it along the wires and
   through closed switches (not through loads), at the current's speed (and speeding up along long stretches in the
   same way), lighting them in the phase's colour. Where a switch closes it carries on from there; where one opens,
   what is cut off goes dark from the break outwards. Two phases joined together, or a phase joined to the control
   circuit, is a short: what they reach stays dark. A transformer whose primary is across two phases works. */
let PARR = new Map(), PDARK = new Map(), phFault = '';   // (PARR: each junction a phase has reached: { k: the phase, t: when })
function phasesNow(t) {
  const PH = NET.PH; if (!PH || !Object.keys(PH).length) return;
  const f = compNow(), cph = new Map(), l1 = f(NET.L1), l2 = f(NET.L2);
  // which phase each joined-up piece carries (-1: two phases, or a phase and L1 or L2)
  for (const L in PH) { const c = f(PH[L]); cph.set(c, cph.has(c) || c === l1 || c === l2 ? -1 : +L); }
  phFault = '';
  for (const L in PH) { const c = f(PH[L]); if (cph.get(c) === -1) { const o = Object.keys(PH).find(k => k !== L && f(PH[k]) === c); phFault = o ? `Short circuit! L${L} is connected straight to L${o}.` : `Short circuit! L${L} is connected straight to the control circuit.`; break; } }
  // where each phase goes: out from its box, along the ways that lead on to a load, through closed poles from their
  // line side (so never back into another starter's load side)
  const reach = new Map();
  for (const L in PH) if (cph.get(f(PH[L])) === +L) {
    reach.set(PH[L], +L); const st = [PH[L]];
    while (st.length) { const u = st.pop(); for (const i of NET.adj[u]) { const e = NET.edges[i], w = e.a === u ? e.b : e.a; if (!reach.has(w) && phStep(e, u)) { reach.set(w, +L); st.push(w); } } }
  }
  const want = n => reach.get(n) || 0;
  const N = NET.nodes.length, lost = [], gain = new Set();
  for (let n = 0; n < N; n++) { const o = PARR.get(n), k = want(n); if (o && o.k !== k) lost.push(n); if (k && (!o || o.k !== k)) gain.add(n); }
  const put = (n, at, c) => { let a = PTL.get(n); if (!a) PTL.set(n, a = [[-1e9, null]]); while (a.length > 1 && a[a.length - 1][0] >= at - 1e-9) a.pop(); a.push([at, c]); if (at > busyUntil) busyUntil = at; };
  // what has been cut off goes dark from where it was cut, outwards
  if (lost.length) {
    const L = new Set(lost), d = new Map(), h = heap();
    // (from where it is still lit, across a wire or a switch, open or shut: never across a load, such as a
    // transformer's primary, whose other end is on another phase)
    for (const n of lost) for (const i of NET.adj[n]) { const e = NET.edges[i], w = e.a === n ? e.b : e.a; if (!L.has(w) && want(w) && (e.kind !== 'part' || isSw(e.part))) { d.set(n, t); h.push(t, n); break; } }
    walk(h, d, n => L.has(n));
    for (const n of lost) { const off = Math.max(t, d.get(n) ?? t), o = PARR.get(n); put(n, off, null); PDARK.set(n, { k: o.k, t: o.t, off }); PARR.delete(n); }
  }
  // what a phase can now reach lights up, spreading out from where it already is (or from its box)
  if (gain.size) {
    const d = new Map(), h = heap();
    for (const L in PH) if (cph.get(f(PH[L])) === +L) { const s = PARR.get(PH[L]); if (s) { d.set(PH[L], Math.max(s.t, t)); h.push(Math.max(s.t, t), PH[L]); } }
    for (const [n, s] of PARR) if (!d.has(n)) { d.set(n, Math.max(s.t, t)); h.push(Math.max(s.t, t), n); }
    for (const n of gain) if (n === PH[(NET.nodes[n].k || '').slice(2)]) { d.set(n, t); h.push(t, n); }
    walk(h, d, n => gain.has(n), phStep);
    for (const n of gain) if (d.has(n)) { const k = want(n), at = d.get(n); PARR.set(n, { k, t: at }); put(n, at, PH_COL[k - 1]); }
  }
  // a transformer fed from the phases: look at it again as each phase reaches its primary
  // (and as it goes dark there)
  const when = n => [PARR.get(n)?.t, PDARK.get(n)?.off].filter(x => x !== undefined && x > t);
  for (const p of parts) if (p.t === 'xfm') for (const n of [p._a, p._b]) for (const at of when(n)) schedule(at, () => updateCoils(evT));
  for (const p of parts) if (p.t === 'mtr') for (const n of p._t) for (const at of when(n)) schedule(at, () => motorsNow(evT));
  motorsNow(t);
  // two phases joined: the fuses on the way between them blow (just after, so they are seen to)
  if (phFault) blowSoon(faultFuses(), t);
  needPaint = true;
}
/* A motor runs with three different phases at T1, T2 and T3 (forward with them in order, L1-L2-L3 or a turn of it;
   backward with any two swapped); with only two it hums without turning, and a few seconds later the overloads
   feeding it trip. MOT: each motor's state, and since when. */
const HUM_TRIP = 3;
function motorsNow(t) {
  for (const p of parts) if (p.t === 'mtr' && p._t) {
    const ks = p._t.map(n => phaseOfAt(n, t)), got = new Set(ks.filter(Boolean));
    const st = got.size === 3 ? 'run' : got.size === 2 ? 'hum' : 'off', dir = st !== 'run' ? 0 : ['123', '231', '312'].includes(ks.join('')) ? 1 : -1;
    const m = MOT[p.id];
    if (m && m.st === st && m.dir === dir) continue;
    const now = MOT[p.id] = { st, dir, t0: t }; needPaint = true;
    if (st === 'hum') schedule(t + HUM_TRIP, () => { if (MOT[p.id] === now) tripFeeding(p, evT); });
  }
}
// trip (or reset) overload L: its contacts in the control circuit open (or close again)
function setTrip(L, on, t) {
  if (!!OLTRIP[L] === on) return;
  if (on) OLTRIP[L] = { t }; else { delete OLTRIP[L]; OLRESET[L] = t; }
  if (t + SWING > busyUntil) busyUntil = t + SWING;
  needPaint = true; switched(parts.filter(q => q.t === 'olc' && q.L === L), t);
}
// the overloads whose heaters a motor is wired through
function tripFeeding(m, t) { const f = compNow(), cs = new Set(m._t.map(n => f(n))); for (const o of parts) if (o.t === 'olh' && o._t && o._t.some(n => cs.has(f(n)))) setTrip(o.L, true, t); }
// the fuse poles between two phases that are joined: taking one out would part them (one side still on one phase,
// the other on another)
function faultFuses() {
  const out = [], PH = NET.PH;
  for (const k of parts.flatMap(p => p.t === 'fus' && p._poles ? p._poles : p.t === 'fu1' ? [p] : [])) {   // (a single fuse is a pole of its own)
    if (BLOWN[k.id]) continue;
    const f = components(NET, e => conducts(e) && e.part !== k), a = f(k._a), b = f(k._b);
    if (a === b) continue;
    const side = c => { const ks = Object.keys(PH).filter(L => f(PH[L]) === c); return ks.length ? ks : c === f(NET.L1) || c === f(NET.L2) ? ['c'] : []; };
    const A = side(a), B = side(b);
    if (A.length && B.length && (A.some(x => !B.includes(x)) || B.some(x => !A.includes(x)))) out.push(k);
  }
  return out;
}
// fuses blow (just after, so they are seen to)
function blowSoon(fs, t) { if (fs.length) schedule(t + .05, () => { const now = fs.filter(k => !BLOWN[k.id]); if (!now.length) return; for (const k of now) { BLOWN[k.id] = { t: evT }; FU1T[k.id] = evT; } switched(now, evT); }); }
// L1 joined straight to L2: the single fuse on the way blows (the first, nearest L1, where there are several in a row)
function shortFuses() {
  const out = [];
  for (const p of [...parts].sort((a, b) => a.x - b.x || a.y - b.y)) if (p.t === 'fu1' && !BLOWN[p.id]) {
    const f = components(NET, e => conducts(e) && e.part !== p);
    if (f(NET.L1) !== f(NET.L2)) { out.push(p); break; }
  }
  return out;
}
// clicked while running: a disconnect's handle (all of it), a fuse (the pole clicked: blown, or put back), an overload
// (trip it, or reset it once tripped), an overload contact (reset)
function workPower(p, i) {
  const t = simT;
  if (p.t === 'dsc') { if (DSC[p.id]) delete DSC[p.id]; else DSC[p.id] = { t }; DSC_T[p.id] = t; if (t + SWING > busyUntil) busyUntil = t + SWING; switched(p._poles, t); }
  else if (p.t === 'fu1') { if (BLOWN[p.id]) delete BLOWN[p.id]; else BLOWN[p.id] = { t }; FU1T[p.id] = t; switched([p], t); }
  else if (p.t === 'fus') { const k = p._poles[i]; if (BLOWN[k.id]) delete BLOWN[k.id]; else BLOWN[k.id] = { t }; FU1T[k.id] = t; switched([k], t); }
  else if (p.t === 'olh') setTrip(p.L, !OLTRIP[p.L], t);
  else if (p.t === 'olc') setTrip(p.L, false, t);
  needPaint = true;
}
let DSC_T = {}, OLRESET = {}, FU1T = {};   // (FU1T: when each fuse, single or a three-pole fuses' pole, last blew or was put back)

// spread out from what is in h (times in d), through wires and closed switches, into the junctions ok allows
function walk(h, d, ok, step = e => conducts(e)) {
  while (h.size()) {
    const [tu, u] = h.pop(); if (tu > d.get(u) + 1e-12) continue;
    for (const i of NET.adj[u]) { const e = NET.edges[i]; if (!step(e, u)) continue;
      const w = e.a === u ? e.b : e.a; if (!ok(w)) continue;
      const tw = tu + stepTime(e); if (!d.has(w) || tw < d.get(w) - 1e-12) { d.set(w, tw); h.push(tw, w); } }
  }
}
// a transformer's primary fed across two phases at time t (each phase there by then)
function phFedAt(p, t) { const a = phaseOfAt(p._a, t), b = phaseOfAt(p._b, t); return a > 0 && b > 0 && a !== b; }
// the phase at junction n at time t: once it has got there, and until the dark has (PDARK: where a phase has been
// cut off, and when it goes dark there)
function phaseOfAt(n, t) { const s = PARR.get(n); if (s && s.t <= t + 1e-9) return s.k; const g = PDARK.get(n); return g && g.t <= t + 1e-9 && g.off > t + 1e-9 ? g.k : 0; }
// a small binary heap of [time, junction]
function heap() {
  const a = [];
  const up = i => { while (i) { const j = (i - 1) >> 1; if (a[j][0] <= a[i][0]) break; [a[i], a[j]] = [a[j], a[i]]; i = j; } };
  const down = i => { for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (r < a.length && a[r][0] < a[m][0]) m = r; if (m === i) return; [a[i], a[m]] = [a[m], a[i]]; i = m; } };
  return { size: () => a.length, push: (t, n) => { a.push([t, n]); up(a.length - 1); }, pop: () => { const top = a[0], last = a.pop(); if (a.length) { a[0] = last; down(0); } return top; } };
}

/* Which way three-phase power goes. Each pole of a disconnect, fuse block or starter passes it only from its line side
   (PLINE: the end a phase box reaches through fewer other poles, then by the shorter way), as current would. And like
   the current in the control circuit, a phase only goes along a way that leads on to a load (a motor's terminal, a
   transformer's primary) without coming back on itself (PUSE: those ways, by jedge and the end they leave from). So a
   wire to an open starter waits, lit, but a starter's load side is never fed back from another starter's. */
let PLINE = new Map(), PUSE = new Set(), PSUB = new Map(), PJE = new Map();
function phaseWays() {
  PLINE = new Map(); PUSE = new Set(); PSUB = new Map(); PJE = new Map();
  if (!NET.PH || !Object.keys(NET.PH).length) return;
  const J = NET.jadj, srcs = [], isP = e => e.kind === 'part' && (e.part.t === 'pp' || e.part.t === 'fu1'),   // (a single fuse on a line: a pole of its own)
    passable = e => e.kind === 'seg' || (e.part && !LOADT(e.part.t));
  for (const p of parts) if (isPh(p) && p._t) srcs.push(...p._t);
  for (const pe of NET.jedges) if (isP(pe)) {
    PJE.set(pe.part, pe);
    const d = new Map(), h = heap();
    for (const s of srcs) { d.set(s, 0); h.push(0, s); }
    while (h.size()) { const [du, u] = h.pop(); if (du > d.get(u)) continue;
      for (const e of J.get(u) || []) { if (e === pe || !passable(e)) continue; const w = e.a === u ? e.b : e.a, nd = du + (isP(e) ? 1e6 : e.len || 1);
        if (!d.has(w) || nd < d.get(w)) { d.set(w, nd); h.push(nd, w); } } }
    PLINE.set(pe.part, (d.get(pe.b) ?? Infinity) < (d.get(pe.a) ?? Infinity) ? pe.b : pe.a);
  }
  const T = new Set();
  for (const p of parts) { if (p.t === 'mtr' && p._t) p._t.forEach(n => T.add(n)); if (p.t === 'xfm' && p._a !== undefined) { T.add(p._a); T.add(p._b); } }
  const can = (e, u) => passable(e) && !(isP(e) && PLINE.get(e.part) !== u);
  for (const e of NET.jedges) for (const u of [e.a, e.b]) {
    if (!can(e, u)) continue;
    const w = e.a === u ? e.b : e.a; let ok = T.has(w);
    if (!ok) { const seen = new Set([u, w]), st = [w];
      while (st.length && !ok) { const x = st.pop(); for (const e2 of J.get(x) || []) { if (!can(e2, x)) continue; const y = e2.a === x ? e2.b : e2.a; if (seen.has(y)) continue; if (T.has(y)) { ok = true; break; } seen.add(y); st.push(y); } } }
    if (ok) PUSE.add(e.i + (u === e.a ? 'a' : 'b'));
  }
  // each small step of wire: the run it is part of, and which of its ends is the one nearer the run's start
  for (const e of NET.jedges) if (e.kind === 'seg') for (let k = 1; k < e.chain.length; k++) { const a = e.chain[k - 1], b = e.chain[k]; PSUB.set(Math.min(a, b) + ',' + Math.max(a, b), { e, first: a }); }
}
// may a phase step along edge e (a small step of wire, or a part) from junction u?
function phStep(e, u) {
  if (!conducts(e)) return false;
  if (e.kind === 'part') {
    if (e.part.t !== 'pp' && e.part.t !== 'fu1') return true;
    const je = PJE.get(e.part); return PLINE.get(e.part) === u && !!je && PUSE.has(je.i + (u === je.a ? 'a' : 'b'));
  }
  const m = PSUB.get(Math.min(e.a, e.b) + ',' + Math.max(e.a, e.b)); if (!m) return true;
  return PUSE.has(m.e.i + (u === m.first ? 'a' : 'b'));
}

/* =====================================================================
   Drawing a sheet: the page (frame, drawing, title block), as it prints. The editor draws its own marks
   (selection, the grid, loose ends, what Check Print found) over the drawing, in a layer that never prints.
   ===================================================================== */
const PW = 4;                                  // the wires' weight (the symbols' lines are drawn to it)
let SHOW = { wn: true, rn: true, xr: true };   // wire numbers, rung numbers, cross-references
let LABS = [], PLABS = [];                     // (PLABS: the parts' tags and labels on the sheet on screen, for dragging)
let XREFS = [], RUNGNUMS = [], LINKS = [];     // (on the sheet on screen: each cross-reference and rung number, for clicking; each dashed link, for dragging)
// the box a line of text takes up (Arial bold, roughly)
// how far a part's name, label or one of its fuse numbers has been dragged (each on its own), and setting it
const labOff = (p, which) => (which === 'tag' ? p.lt : which === 'desc' ? p.ld : (p.lf || {})[which]) || [0, 0];
function setLabOff(p, which, v) { if (which === 'tag') p.lt = v; else if (which === 'desc') p.ld = v; else (p.lf ||= {})[which] = v; }
// a continuation's note: TO / FROM the other sheet with its letter (or, on the same sheet, the rung)
function contNote(p, k) {
  const other = p.t === 'cnt_out' ? 'cnt_in' : 'cnt_out', m = allParts().find(q => q.p.t === other && q.p.tag === p.tag);
  if (!m) return p.t === 'cnt_out' ? 'TO ?' : 'FROM ?';
  const w = p.t === 'cnt_out' ? 'TO' : 'FROM';
  if (m.k !== k) return `${w} SHEET ${m.k + 1}`;
  const rn = A && A.rung && A.rung.get(m.p.id); return rn ? `${w} RUNG ${rn}` : `${w} ${m.p.tag}`;
}
/* ---------- what Circuit Builder's devices carry into the print ---------- */
// one pushbutton (or selector switch) drawn in several rungs: the parts with its number are its contact blocks; the top
// one is the operator itself (a selector's turning arrow is drawn on it only)
const isPB = p => p.t === 'pb_no' || p.t === 'pb_nc' || p.t === 'pbm_no' || p.t === 'pbm_nc';
const blocksOf = p => allParts().map(q => q.p).filter(q => q.tag && q.tag === p.tag && (isPB(p) ? isPB(q) : q.t === p.t)).sort((a, b) => a.y - b.y || a.x - b.x);
const mainBlock = p => blocksOf(p)[0] || p;
function blockGroups(s) { const g = new Map(); for (const p of s.parts) if ((isPB(p) || p.t === 'sel') && p.tag) { const k = (p.t === 'sel' ? 'S:' : 'P:') + p.tag; if (!g.has(k)) g.set(k, []); g.get(k).push(p); }
  return [...g.values()].map(bs => bs.sort((a, b) => a.y - b.y)).filter(bs => bs.length > 1); }
// the timer a contact belongs to (its coil, if that is a timer)
const timerOf = p => { const c = allParts().find(q => q.p.t === 'coil' && q.p.tag === p.tag); return c && /^TR/.test(c.p.tag) ? c.p : null; };
// the print symbol a part is drawn with: a timer's contacts timed (unless instant); a selector's extra blocks without the arrow
function symOf(p) {
  if (p.t === 'tc_no' || p.t === 'tc_nc') { const tm = timerOf(p); return `${p.t === 'tc_no' ? 'NO' : 'NC'} ${tm && tm.tof ? 'FD' : 'ND'} Switch`; }   // (timed: on- or off-delay as its timer is)
  if (p.t === 'sel' && mainBlock(p) !== p) return 'Selector Switch';
  return LIB[p.t].sym;
}
// what is written under a part: its label, and what Circuit Builder would add (a timer's delay, the positions a selector's
// block is closed in, the button a light is built into, the light built into a button)
function noteOf(p) {
  const n = [p.desc || LIB[p.t].note];
  if (p.t === 'coil' && /^TR/.test(p.tag || '')) n.push(`${p.tof ? 'OFF' : 'ON'}-DELAY${p.delay ? ' ' + p.delay + ' s' : ''}`);
  if (p.t === 'sel') { const names = selNames(p), cl = (p.closedIn || []).map(i => names[i]).filter(Boolean); n.push(cl.length ? 'CLOSED: ' + cl.join(', ') : 'OPEN IN ALL'); }
  if (p.t === 'pl' && p.inPB) n.push('IN ' + p.inPB);
  if (isPB(p) && mainBlock(p) === p) { const ls = allParts().filter(q => q.p.t === 'pl' && q.p.inPB === p.tag).map(q => q.p.tag); if (ls.length) n.push('LIGHTED (' + ls.join(', ') + ')'); }
  return n.filter(Boolean).join(' · ');
}
const selNames = p => (p.pos || 'OFF/ON').split(/[\/,]+/).map(x => x.trim().toUpperCase()).filter(Boolean).slice(0, 4);
function lblBox(x, y, t, size, anchor) { const w = String(t).length * size * .62, x0 = anchor === 'start' ? x : anchor === 'end' ? x - w : x - w / 2; return { x0, x1: x0 + w, y0: y - size * .8, y1: y + size * .15 }; }                                 // the wire numbers on the sheet on screen: { id (its wire), l, x, y, anchor, x0..y1 }
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// the sheet's drawing (no editor marks): an SVG group's insides
function drawSheet(s, k, A) {
  let g = ''; PLABS = []; XREFS = []; RUNGNUMS = []; LINKS = [];
  const line = (x1, y1, x2, y2, w = PW) => { g += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${w}"/>`; };
  const text = (x, y, t, size = 26, anchor = 'middle', weight = 700, extra = '') => { if (t !== '' && t != null) g += `<text x="${x}" y="${y}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}"${extra}>${esc(t)}</text>`; };
  const arrow = (x, y, ux, uy) => { const bx = x - ux * 22, by = y - uy * 22, px = -uy * 13, py = ux * 13;
    g += `<path d="M${bx + px} ${by + py}L${bx - px} ${by - py}L${x} ${y}Z" fill="#000" stroke="#000" stroke-width="2"/>`; };
  // rails
  const rails = s.parts.filter(p => p.t === 'rail');
  for (const r of rails) { line(r.x, r.y0, r.x, r.y1);
    // (fed at its top by a wire, from the transformer: no arrow, its name beside it)
    const fed = s.wires.some(w => [w.a, w.b].some(e => e.r === r.id && e.y <= r.y0));
    if (fed) text(r.x + (r.label === 'L1' ? -14 : 14), r.y0 + 40, r.label, 26, r.label === 'L1' ? 'end' : 'start');
    else { arrow(r.x, r.y0, 0, 1); text(r.x, r.y0 - 34, r.label, 28); } }
  // wires, then their numbers (placed clear of the symbols, their tags and the other wires; see wireLabels)
  for (const w of s.wires) g += `<polyline points="${wirePts(s, w).map(q => q.join(',')).join(' ')}"/>`;
  LABS = SHOW.wn ? wireLabels(s, A) : [];
  for (const L of LABS) text(L.x, L.y, L.l, 22, L.anchor);
  // joints: three or more wires at a node or a terminal; a wire teed onto a rail
  const deg = new Map(), bump = (x, y) => { const c = x + ',' + y; deg.set(c, (deg.get(c) || 0) + 1); };
  for (const w of s.wires) for (const e of [w.a, w.b]) { const [x, y] = pos(s, e); if (e.r) { const r = partOf(s, e.r); if (r && y > r.y0 && y < r.y1) { deg.set(x + ',' + y, 9); continue; } } bump(x, y); }
  for (const [c, n] of deg) { if (n < 3) { const [x, y] = c.split(',').map(Number); if (!(n === 2 && s.parts.some(p => p.t !== 'rail' && [...Array(termsN(p)).keys()].some(i => { const q = termPos(p, i); return q[0] === x && q[1] === y; })))) continue; }
    const [x, y] = c.split(',').map(Number); g += `<circle cx="${x}" cy="${y}" r="7" fill="#000" stroke="none"/>`; }
  // (the contact blocks of one pushbutton or selector switch, one above another: a dashed line links each to the next down)
  const linked = new Set(blockGroups(s).flat().map(p => p.id));
  // (a light built into a pushbutton: a dashed link from the nearest block of that button to the light. The contact
  // blocks of one pushbutton or selector, one above another: a dashed link from each to the next down. Each is routed
  // by linkRoute; dragged into another shape, it keeps that shape (see LINK_ in editor.js))
  for (const L of linksOf(s)) { linked.add(L.a.id); linked.add(L.b.id);
    const P = linkRoute(L); LINKS.push({ ...L, pts: P });
    g += `<polyline points="${P.map(q => q.join(',')).join(' ')}" fill="none" stroke-width="3" stroke-dasharray="12 10" stroke-linecap="butt" stroke-linejoin="miter"/>`; }
  // devices
  for (const p of s.parts) {
    if (p.t === 'rail') continue;
    // (a part's tag and label: where they go, moved by however far they have been dragged; each one's box kept for picking)
    const lt = p.lt || [0, 0], ld = p.ld || [0, 0];
    // (a linked block's name and note: a white edge, so the dashed link between the blocks breaks around them)
    const halo = linked.has(p.id) ? ' stroke="#fff" stroke-width="8" stroke-linejoin="round" paint-order="stroke"' : '';
    const tagT = (x, y, t, size, anchor = 'middle', which = 'tag') => { if (!t) return; const o = labOff(p, which); x += o[0]; y += o[1]; text(x, y, t, size, anchor, 700, halo); PLABS.push({ id: p.id, which, ...lblBox(x, y, t, size, anchor) }); };
    const descT = (x, y, t, size, anchor = 'middle') => { if (!t) return; x += ld[0]; y += ld[1]; text(x, y, t, size, anchor, 500, halo); PLABS.push({ id: p.id, which: 'desc', ...lblBox(x, y, t, size, anchor) }); };
    if (isArrowIn(p.t)) {   // (a line in: its arrow points along the wire, its name behind it; turned and flipped with it)
      const u = place(p, [1, 0]), n = place(p, [-34, 0]); arrow(p.x, p.y, u[0], u[1]);
      tagT(p.x + n[0], p.y + n[1] + (u[1] ? (u[1] > 0 ? -6 : 30) : 10), p.tag, 28, u[0] > 0 ? 'end' : u[0] < 0 ? 'start' : 'middle'); continue; }
    const sym = PSYM[symOf(p)], r = p.rot || 0, kind = LIB[p.t].kind;
    g += `<g class="sym" transform="${xform(p)}">${sym.b}</g>`;
    if (kind === 'cont') {   // (its letter inside the arrow; under it, where it goes or comes from)
      const c = place(p, [-6, 0]); text(p.x + c[0], p.y + c[1] + 9, p.tag, (p.tag || '').length > 2 ? 18 : 24);
      // (lying down: its note under it; standing up: beside it)
      if (r % 180) descT(p.x + 34, p.y + c[1] + 7, p.desc || contNote(p, k), 18, 'start'); else descT(p.x, p.y + 46, p.desc || contNote(p, k), 18); continue; }
    const up = r % 180 !== 0, inside = (kind === 'coil' && (p.tag || '').length <= 4) || kind === 'motor';
    // (a fuse block or fused disconnect stood on end: each fuse its number beside it, across from the fuse; the disconnect's name over all)
    if (up && (p.t === 'fus3' || p.t === 'fdsc3')) { const tg = tagsOf(p), fu = p.t === 'fus3' ? tg : tg.slice(1), fx = p.t === 'fus3' ? 0 : 40;
      fu.forEach((t, i) => { const c = place(p, [fx, -120 + 120 * i]); tagT(p.x + c[0] + 18, p.y + c[1] + 9, t, 26, 'start', 'fu' + i); });
      if (p.t === 'fdsc3') { const c = place(p, [-40, 0]), top = Math.min(...[0, 1, 2, 3, 4, 5].map(i => termPos(p, i)[1])); tagT(p.x + c[0], top - 16, p.tag, 26); }
    } else if (up) { const off = Math.max(Math.abs(sym.y0), Math.abs(sym.y1)) + 10; tagT(p.x + off, p.y + 9, p.tag, 26, 'start'); if (noteOf(p)) descT(p.x + off, p.y + 34, noteOf(p), 20, 'start'); }
    else {
      const y0 = r === 180 ? -sym.y1 : sym.y0, y1 = r === 180 ? -sym.y0 : sym.y1;
      if (p.t === 'fdsc3' && !r) tagsOf(p).slice(1).forEach((tg, i) => tagT(p.x + (p.fx ? -40 : 40), termPos(p, 2 * i)[1] - 24, tg, 26, 'middle', 'fu' + i));   // (a fused disconnect's fuses, each its number)
      if (p.t === 'fus3' && !r) tagsOf(p).forEach((tg, i) => tagT(p.x, termPos(p, 2 * i)[1] - 24, tg, 26, 'middle', 'fu' + i));   // (each fuse its own number)
      else if (inside) text(p.x, p.y + (kind === 'motor' ? 11 : 10), p.tag, kind === 'motor' ? 30 : (p.tag || '').length > 3 ? 22 : 27); else tagT(p.x + (p.t === 'fdsc3' && !r ? (p.fx ? 40 : -40) : 0), p.y + y0 - 8, p.tag, 26);   // (a fused disconnect's name over its switch, clear of its fuse numbers)
      if (noteOf(p)) descT(p.x, p.y + y1 + 22, noteOf(p), 20);
    }
    if (p.t === 'xfmr') { const t = [0, 1, 2, 3].map(i => termPos(p, i)), nm = ['H1', 'H2', 'X1', 'X2'];
      // (each name beside its own end, whichever way the transformer is turned or flipped)
      t.forEach((q, i) => { const d = [q[0] - p.x, q[1] - p.y], hz = Math.abs(d[0]) >= Math.abs(d[1]); text(q[0] + (hz ? Math.sign(d[0]) * 12 : 0) + (hz ? 0 : (d[0] < 0 ? -12 : 12)), q[1] + (d[1] < 0 ? -8 : 22), nm[i], 18, d[0] > 0 ? 'start' : 'end', 600); }); }
  }
  // rung numbers, left of L1; cross-references, right of L2
  const rL1 = rails.find(r => r.label === 'L1'), rL2 = rails.find(r => r.label === 'L2');
  if (SHOW.rn) for (const { y, n } of A.rows[k] || []) {
    // (left of everything on its row: L1, the symbols, and any wire that runs along the row or comes down across it)
    const xs = s.parts.filter(p => p.t !== 'rail' && p.y === y).map(p => p.x + extOf(p).x0);
    for (const w of s.wires) { const P = wirePts(s, w); for (let i = 0; i < P.length - 1; i++) { const [a, b] = [P[i], P[i + 1]];
      if (a[1] === y && b[1] === y) xs.push(Math.min(a[0], b[0])); else if (a[0] === b[0] && Math.min(a[1], b[1]) <= y && Math.max(a[1], b[1]) >= y) xs.push(a[0]); } }
    if (rL1 && y >= rL1.y0 && y <= rL1.y1) xs.push(rL1.x);
    if (xs.length) { const x = Math.min(...xs) - 50; text(x, y + 9, n, 24, 'end'); RUNGNUMS.push({ n, y, x0: x - String(n).length * 15 - 4, x1: x + 4, y0: y - 14, y1: y + 14 }); }
  }
  if (SHOW.xr) for (const p of s.parts) { const r = A.xref.get(p.id); if (!r || !r.length) continue;
    // (right of everything on its row: L2, the symbols, and any wire along the row or crossing it)
    const xs = s.parts.filter(q => q.t !== 'rail' && q.y === p.y).map(q => q.x + extOf(q).x1);
    for (const w of s.wires) { const P = wirePts(s, w); for (let i = 0; i < P.length - 1; i++) { const [a, b] = [P[i], P[i + 1]];
      if (a[1] === p.y && b[1] === p.y) xs.push(Math.max(a[0], b[0])); else if (a[0] === b[0] && Math.min(a[1], b[1]) <= p.y && Math.max(a[1], b[1]) >= p.y) xs.push(a[0]); } }
    if (rL2 && p.y >= rL2.y0 && p.y <= rL2.y1) xs.push(rL2.x);
    const x = Math.max(...xs) + 26;
    g += `<text x="${x}" y="${p.y + 9}" font-size="22" font-weight="700">${r.map(o => o.nc ? `<tspan text-decoration="underline">${o.n}</tspan>` : o.n).join(', ')}</text>`;
    // (each number's box, for clicking: it goes to that rung; PWR goes to the coil's power contacts)
    let cx = x; for (const o of r) { const w = String(o.n).length * 13.4; XREFS.push({ n: o.n, tag: p.tag, x0: cx - 3, x1: cx + w + 3, y0: p.y - 12, y1: p.y + 14 }); cx += w + 12; } }
  // notes
  for (const t of s.texts) { const lines = String(t.s || '').split('\n');
    g += `<text x="${t.x}" y="${t.y}" font-size="${t.size || 24}" font-weight="${t.bold ? 700 : 500}">${lines.map((l, i) => `<tspan x="${t.x}" dy="${i ? (t.size || 24) * 1.25 : 0}">${esc(l)}</tspan>`).join('')}</text>`; }
  return g;
}

// the title block: its fields in a 12-column grid, rows filled in order; its notes under them
function tbHTML(k, n) {
  const tb = doc.tb, val = v => String(v ?? '').replace(/\{sheet\}/gi, `${k + 1} of ${n}`).replace(/\{date\}/gi, today());
  // (a box that would not fit on its row starts the next: the row's end filled, so no gaps show)
  let cells = '', col = 0;
  const fill = n => { if (n > 0) cells += `<div class="tbf" style="grid-column: span ${n}"></div>`; };
  for (const f of tb.fields) { const sp = Math.max(1, Math.min(12, f.span || 2)); if (col + sp > 12) { fill(12 - col); col = 0; }
    cells += `<div class="tbf${f.big ? ' big' : ''}" style="grid-column: span ${sp}"><div class="k">${esc(f.label)}</div><div class="v">${esc(val(f.value))}</div></div>`; col = (col + sp) % 12; }
  if (col) fill(12 - col);
  const lines = (tb.showNotes ? tb.notes.split('\n').filter(l => l.trim()) : []).concat(tb.powerNote !== false && hasPower() ? [POWER_NOTE] : []);
  const notes = lines.length ? `<div class="notes"><span class="k">Notes</span>${lines.map((l, i) => `<span>${i + 1}. ${esc(l)}</span>`).join('')}</div>` : '';
  return `<div class="pr-tb">${cells}${notes}</div>`;
}
// a whole page; the drawing's viewBox is set once it is laid out (see fitDraw)
function pageHTML(s, k, A, editor = false) {
  return `<div class="pr-page${s.land ? ' land' : ''}" data-k="${k}"><div class="pr-frame"><div class="pr-draw"><svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin meet"${editor ? ' id="sv"' : ''}>${editor ? '<g id="ed-under"></g>' : ''}<g class="ink" fill="none" stroke="#000" stroke-width="${PW}" stroke-linecap="round" stroke-linejoin="round">${drawSheet(s, k, A)}</g>${editor ? '<g id="ed-over"></g>' : ''}</svg></div>${tbHTML(k, doc.sheets.length)}</div></div>`;
}
// a page's drawing given its viewBox: a unit 1/312.5 in, whatever the room the title block leaves
function fitDraw(page) {
  const d = page.querySelector('.pr-draw'), svg = d.querySelector('svg'), cs = getComputedStyle(d);
  const w = d.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), h = d.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
  const vw = Math.round(w * U_IN / 96), vh = Math.round(h * U_IN / 96);
  svg.setAttribute('viewBox', `0 0 ${vw} ${vh}`);
  return [vw, vh];
}

/* ---------- wire numbers: where each goes ---------- */
// One number for each run of wire: wires that carry straight on through a joint count as one run (as Circuit
// Builder prints them). Each goes above a level run or beside an upright one, at the first spot that is clear of
// the symbols and their tags, the other numbers and the other wires; one dragged somewhere stays there.
function wireLabels(s, A) {
  const out = [], boxes = s.parts.filter(p => p.t !== 'rail').map(p => partBox(p));
  for (const t of s.texts) boxes.push(textBox(t));
  for (const r of s.parts) if (r.t === 'rail') boxes.push({ x0: r.x - 30, x1: r.x + 30, y0: r.y0 - 60, y1: r.y0 + 50 });
  const segs = s.wires.flatMap(w => { const P = wirePts(s, w); return P.slice(1).map((q, i) => ({ w, a: P[i], b: q })); });
  const hits = (R, own) => boxes.some(b => R.x0 < b.x1 && R.x1 > b.x0 && R.y0 < b.y1 && R.y1 > b.y0) || out.some(b => R.x0 < b.x1 + 6 && R.x1 > b.x0 - 6 && R.y0 < b.y1 + 4 && R.y1 > b.y0 - 4)
    || segs.some(g => !own.has(g.w) && Math.max(g.a[0], g.b[0]) >= R.x0 - 8 && Math.min(g.a[0], g.b[0]) <= R.x1 + 8 && Math.max(g.a[1], g.b[1]) >= R.y0 - 16 && Math.min(g.a[1], g.b[1]) <= R.y1 + 16);
  const rect = (l, x, y, anchor) => { const wd = String(l).length * 13 + 4, x0 = anchor === 'start' ? x : anchor === 'end' ? x - wd : x - wd / 2; return { x0, x1: x0 + wd, y0: y - 18, y1: y + 3 }; };
  const runs = runsOf(s);
  // (the ones dragged into place first, so the others keep clear of them)
  const list = [...new Set(runs.values())].sort((a, b) => (b.some(w => w.lab) ? 1 : 0) - (a.some(w => w.lab) ? 1 : 0));
  for (const ws of list) {
    const l = A.label.get(A.wireRoot(s, ws[0])); if (!l || ws.every(w => w.hideNum)) continue;
    const own = new Set(ws), fixed = ws.find(w => w.lab && !w.hideNum);
    if (fixed) { const [x, y] = fixed.lab; out.push({ id: fixed.id, l, x, y, anchor: 'middle', ...rect(l, x, y, 'middle') }); continue; }
    const cand = [];
    for (const w of ws) { if (w.hideNum) continue; const P = wirePts(s, w);
      for (let i = 0; i < P.length - 1; i++) { const a = P[i], b = P[i + 1], h = a[1] === b[1], len = Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]); if (len < 40) continue;
        cand.push({ w, a, b, h, len, sc: len * (h ? 2 : 1) }); } }
    cand.sort((p, q) => q.sc - p.sc);
    let put = null;
    for (const c of cand) { for (const f of [.5, .35, .65, .2, .8]) { const spots = c.h ? [[c.a[0] + (c.b[0] - c.a[0]) * f, c.a[1] - 9, 'middle'], [c.a[0] + (c.b[0] - c.a[0]) * f, c.a[1] + 27, 'middle']]
        : [[c.a[0] + 10, c.a[1] + (c.b[1] - c.a[1]) * f + 8, 'start'], [c.a[0] - 10, c.a[1] + (c.b[1] - c.a[1]) * f + 8, 'end']];
        for (const [x, y, an] of spots) { const R = rect(l, x, y, an); if (!hits(R, own)) { put = { id: c.w.id, l, x: Math.round(x), y: Math.round(y), anchor: an, ...R }; break; } }
        if (put) break; } if (put) break; }
    if (!put && cand.length) { const c = cand[0], x = c.h ? (c.a[0] + c.b[0]) / 2 : c.a[0] + 10, y = c.h ? c.a[1] - 9 : (c.a[1] + c.b[1]) / 2 + 8, an = c.h ? 'middle' : 'start'; put = { id: c.w.id, l, x, y, anchor: an, ...rect(l, x, y, an) }; }
    if (put) out.push(put);
  }
  return out;
}
// the runs of wire on a sheet: wire id → the wires of its run (wires carrying straight on through a joint)
function runsOf(s) {
  const up = new Map(s.wires.map(w => [w.id, w.id])), find = id => { while (up.get(id) !== id) id = up.get(id); return id; };
  for (const n of s.nodes) { const ws = wiresAt(s, { n: n.id }), dir = w => { const P = wirePts(s, w), at = sameEnd(w.a, { n: n.id }) ? 0 : P.length - 1, o = P[at ? at - 1 : 1]; return [Math.sign(o[0] - n.x), Math.sign(o[1] - n.y)]; };
    for (let i = 0; i < ws.length; i++) for (let j = i + 1; j < ws.length; j++) { const a = dir(ws[i]), b = dir(ws[j]); if (a[0] === -b[0] && a[1] === -b[1]) up.set(find(ws[i].id), find(ws[j].id)); } }
  const g = new Map(); for (const w of s.wires) { const r = find(w.id); if (!g.has(r)) g.set(r, []); g.get(r).push(w); }
  return new Map(s.wires.map(w => [w.id, g.get(find(w.id))]));
}
const runWires = w => runsOf(S).get(w.id) || [w];

/* ---------- the power circuit's wire numbers, explained on the print (as Circuit Builder prints it) ---------- */
const POWER_NOTE = 'Power wires: L1, L2, L3 coming in, a letter added past each device (L1A, L1B…); past a starter’s contacts, motor 1’s leads are T1–T3, motor 2’s T4–T6, lettered again past each overload (T1A).';
// (a print with a power circuit: three-phase lines in, or a starter, motor or three-pole part anywhere)
const hasPower = () => doc.sheets.some(s => s.parts.some(p => p.t === 'sup' || p.t === 'motor' || /3$/.test(p.t) || LIB[p.t] && LIB[p.t].kind === 'starter'));

/* ---------- dashed links: a lighted pushbutton to its light; a pushbutton's or selector's blocks, each to the next ---------- */
// every link on a sheet: { kind: 'light' | 'block', a (the button, or the upper block), b (the light, or the lower block),
// own (the part its shape is kept on: the light, or the lower block) }
function linksOf(s) {
  const out = [];
  for (const l of s.parts) if (l.t === 'pl' && l.inPB && !l.rot) {
    const bs = s.parts.filter(q => isPB(q) && q.tag === l.inPB && !q.rot); if (!bs.length) continue;
    const b = bs.sort((u, v) => Math.hypot(u.x - l.x, u.y - l.y) - Math.hypot(v.x - l.x, v.y - l.y))[0];
    out.push({ kind: 'light', a: b, b: l, own: l });
  }
  for (const bs of blockGroups(s)) for (let i = 1; i < bs.length; i++) if (!(bs[i].rot || bs[i - 1].rot)) out.push({ kind: 'block', a: bs[i - 1], b: bs[i], own: bs[i] });
  return out;
}
// a part's box for a link's ends (its symbol's extent)
const linkBox = p => { const s = PSYM[symOf(p)], e = extOf(p); return { x0: p.x + e.x0, x1: p.x + e.x1, y0: p.y + s.y0, y1: p.y + s.y1 }; };
// where an end sits: on the top or bottom of the part (slid along by o), or its left or right side (a little above the
// rung); 'stem' is just above a pushbutton's wire, where a block's dashed link has always started
function linkEnd(p, e) { const b = linkBox(p), o = e.o || 0;
  if (e.s === 'top') return [p.x + o, b.y0]; if (e.s === 'bottom') return [p.x + o, b.y1]; if (e.s === 'stem') return [p.x + o, p.y - 20];
  return [e.s === 'left' ? b.x0 : b.x1, p.y - 30]; }
const vertEnd = s => s === 'top' || s === 'bottom' || s === 'stem';
// the ends a link starts with (before any are dragged): the upper part's bottom to the lower part's top; two side by side
// on one rung: over the top of both; a pushbutton's blocks lined up: from just above the upper one's wire
function linkEnds(L) {
  const k = L.own.lk || {}, [hi, lo] = L.a.y <= L.b.y ? [L.a, L.b] : [L.b, L.a];
  let da, db;
  if (L.a.y === L.b.y) da = db = { s: 'top' };
  else if (L.kind === 'block' && L.a.x === L.b.x) { da = { s: 'stem' }; db = { s: 'top' }; }
  else { da = { s: L.a === hi ? 'bottom' : 'top' }; db = { s: L.b === lo ? 'top' : 'bottom' }; }
  return [{ ...da, ...(k.ea || {}) }, { ...db, ...(k.eb || {}) }];
}
// the link's line: straight when its ends line up and face each other; otherwise out of each end and across (an upright
// pair of ends: across at a level between them, or over/under both; a side pair: down/up at an upright between them)
function linkRoute(L) {
  const k = L.own.lk || {}, [ea, eb] = linkEnds(L), A_ = linkEnd(L.a, ea), B = linkEnd(L.b, eb), va = vertEnd(ea.s), vb = vertEnd(eb.s);
  if (va && vb) {
    const down = s => s !== 'top', [up, lo] = A_[1] <= B[1] ? [[A_, ea], [B, eb]] : [[B, eb], [A_, ea]];
    if (A_[0] === B[0] && !k.dy && down(up[1].s) && !down(lo[1].s)) return [A_, B];
    let my = !down(ea.s) && !down(eb.s) ? Math.min(A_[1], B[1]) - 50 : down(ea.s) && down(eb.s) ? Math.max(A_[1], B[1]) + 50 : snap((A_[1] + B[1]) / 2);
    my += k.dy || 0; return [A_, [A_[0], my], [B[0], my], B];
  }
  if (!va && !vb) { let mx = ea.s === eb.s ? (ea.s === 'left' ? Math.min(A_[0], B[0]) - 40 : Math.max(A_[0], B[0]) + 40) : snap((A_[0] + B[0]) / 2);
    mx += k.dx || 0; return [A_, [mx, A_[1]], [mx, B[1]], B]; }
  return va ? [A_, [A_[0], B[1]], B] : [A_, [B[0], A_[1]], B];
}

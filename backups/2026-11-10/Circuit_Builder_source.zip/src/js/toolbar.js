// toolbar parts: drag one onto the panel, or click it to put it in a free spot there (see placeFree)
document.querySelectorAll('.tool[data-part]').forEach(b => {
  const kind = b.dataset.part;
  b.addEventListener('pointerdown', e => {
    if (e.button !== 0 || !editing) return;
    e.preventDefault();
    const sx = e.clientX, sy = e.clientY; let moved = false, ghost = null;
    const sample = kind === 'coil' ? { t: 'coil', L: '?', color: '#FFDC00' } : kind.startsWith('timer') ? { t: 'coil', L: '?', color: '#FFDC00', delay: 5, tof: kind === 'timer-off' } : kind === 'lamp' ? { t: 'lamp', L: '', color: '#00B050' } : kind === 'sol' ? { t: 'sol', L: '?', color: SOL_COL } : kind === 'htr' ? { t: 'htr', L: '?', color: HTR_COL } : kind === 'jmp' ? { t: 'jmp', L: '?' } : kind === 'xfm' ? { t: 'xfm', L: '?' } : kind.startsWith('con') ? { t: 'con', L: '?', nc: kind.startsWith('con-nc') } : kind === 'sel' ? { t: 'sel', L: '?', n: 3, closedIn: [0], pos: 1, color: '#0070C0' } : kind.startsWith('src-') ? { t: kind.slice(4), L: '' } : kind.startsWith('psw') ? { t: 'psw', L: '?', nc: kind === 'psw-nc', color: PSW_COL } : kind.startsWith('tsw') ? { t: 'tsw', L: '?', nc: kind.startsWith('tsw-nc'), low: kind.endsWith('l'), color: TSW_COL } : kind.startsWith('lsw') ? { t: 'lsw', L: '?', nc: kind === 'lsw-nc' || kind === 'lsw-nch', held: kind.endsWith('h'), color: LSW_COL } : kind.startsWith('ph-') ? { t: 'ph', L: kind.slice(3) } : ['dsc', 'fus', 'fu1', 'mst', 'olh', 'mtr'].includes(kind) ? { t: kind, L: kind === 'mst' ? 'M' : '?' } : kind === 'olc' ? { t: 'olc', L: '?', nc: true } : kind === 'btn-estop' ? { t: 'btn', L: '?', nc: true, maint: true, estop: true, color: ESTOP_COL } : { t: 'btn', L: '?', nc: kind.startsWith('btn-nc'), color: '#9a9a9a' };
    const mv = ev => {
      if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) > 5) { moved = true; closeMenus(); ghost = document.createElement('div'); ghost.className = 'ghost'; ghost.innerHTML = b.innerHTML; document.body.append(ghost); document.body.classList.add('dragging'); }
      if (!moved) return;
      ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px';
      const r = pt(ev), box = svg.getBoundingClientRect();
      if (ev.clientY >= box.top && ev.clientY <= box.bottom && ev.clientX >= box.left && ev.clientX <= box.right) {
        const [x, y] = clampPart(r.x, r.y, sample.t);
        const T = WIDE(sample.t) ? 60 : 40, hits = [[x - T, y], [x + T, y]].filter(([a, c]) => connects(pointInfo(a, c)));
        preview = { part: { p: sample, x, y, bad: overlaps(null, x, y, sample.t) }, splice: !!spliceTarget(x, y, sample.t), hits }; drawPreview();
      } else { preview = null; view.overlay.innerHTML = ''; }
    };
    const up = ev => {
      document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up);
      if (moved) { ghost.remove(); document.body.classList.remove('dragging'); preview = null; view.overlay.innerHTML = '';
        const r = pt(ev), box = svg.getBoundingClientRect();
        if (ev.clientX >= box.left && ev.clientX <= box.right && ev.clientY >= box.top && ev.clientY <= box.bottom) placePart(kind, r.x, r.y); }
      else { closeMenus(); setTool('select'); placeFree(kind); }   // (a click: it goes onto the panel, in a free spot)
    };
    document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up);
  });
});
function setTool(t) {
  tool = t; closeMenus();
  document.querySelectorAll('.tool[data-tool], .tool[data-part]').forEach(b => b.setAttribute('aria-pressed', String((b.dataset.tool || b.dataset.part) === t)));
  svg.style.cursor = t === 'select' ? '' : 'crosshair';
  say(t !== 'select' && t !== 'wire' ? 'Click the panel to place it (or drag the tool onto the panel). Press Esc to cancel.' : '');
}
document.querySelectorAll('.tool[data-tool]').forEach(b => b.addEventListener('click', () => setTool(b.dataset.tool)));
function del() {
  if (picDel()) return;
  if (!sel) return;
  snapshot();
  parts = parts.filter(q => !sel.parts.has(q.id));
  wires = wires.filter(w => !sel.wires.has(w.id));
  sel = null; draw();
}
document.getElementById('del').addEventListener('click', del);
document.getElementById('undo').addEventListener('click', undo);
document.getElementById('redo').addEventListener('click', redo);
document.getElementById('p-del').addEventListener('click', del);
document.getElementById('clear').addEventListener('click', () => { snapshot(); parts = []; wires = []; W_USER = null; sel = null; circuitName = ''; forgetFile(); draw(); });
document.addEventListener('keydown', e => {
  if (!editing || /SELECT|INPUT/.test(document.activeElement.tagName)) return;
  if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); del(); }
  else if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'y' || e.shiftKey && e.key.toLowerCase() === 'z')) { e.preventDefault(); redo(); }
  else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); }
  else if (e.key === 'Escape') { setTool('select'); sel = null; draw(); }
  else if (e.key.toLowerCase() === 'r' && !e.ctrlKey && !e.metaKey && !e.altKey) { const G = selGroup(); if (G.length && G.every(turns)) { e.preventDefault(); each(p => { p.rot = ((p.rot || 0) + 1) % 4; if (!p.rot) delete p.rot; }); } }
});

/* ---------------- the ribbon ----------------
   Home while building (and the gold tab of the selected part), Simulation while running. Folded away, only the tabs
   show: pressing one opens the ribbon over the panel until you press somewhere else. */
function closeMenus() { document.body.classList.remove('ribbon-peek'); tpMenu(false); }
function showRibbon() {
  const run = !editing, part = !run && selGroup().length > 0, tab = run ? 'run' : part && ribbonTab === 'part' ? 'part' : mainTab;
  const set = (id, shown, on) => { const b = document.getElementById(id); b.hidden = !shown; b.setAttribute('aria-pressed', String(on)); };
  set('rt-home', !run, tab === 'home'); set('rt-part', part, tab === 'part'); set('rt-run', run, tab === 'run');
  document.getElementById('toolbar').hidden = tab !== 'home';
  if (tab !== 'home') tpMenu(false);
  document.getElementById('editpanel').hidden = tab !== 'part';
  document.getElementById('runbar').hidden = tab !== 'run';
}
for (const [id, t] of [['rt-home', 'home'], ['rt-part', 'part'], ['rt-run', 'run']])
  document.getElementById(id).addEventListener('click', () => {
    if (t !== 'run') ribbonTab = t;
    if (t === 'home') mainTab = t;
    if (document.body.classList.contains('ribbon-min') || document.body.classList.contains('fs')) document.body.classList.add('ribbon-peek');
    showRibbon();
  });
const RIBBON_KEY = 'oo-circuit-builder:ribbon-min';
function foldRibbon(min) {
  document.body.classList.toggle('ribbon-min', min); document.body.classList.remove('ribbon-peek');
  const b = document.getElementById('ribbon-toggle');
  b.setAttribute('aria-expanded', String(!min)); b.setAttribute('aria-label', min ? 'Pin the ribbon open' : 'Collapse the ribbon');
  b.dataset.tip = min ? 'Keep the ribbon open' : 'Fold the ribbon away for more room (the tabs stay)';
  b.classList.toggle('down', min);
  try { localStorage.setItem(RIBBON_KEY, min ? '1' : ''); } catch (_) {}
  if (fit(editing)) { if (editing) fitView(); }
  draw();
}
document.getElementById('ribbon-toggle').addEventListener('click', () => foldRibbon(!document.body.classList.contains('ribbon-min')));
try { if (localStorage.getItem(RIBBON_KEY) === '1') { document.body.classList.add('ribbon-min'); const b = document.getElementById('ribbon-toggle'); b.setAttribute('aria-expanded', 'false'); b.classList.add('down'); b.dataset.tip = 'Keep the ribbon open'; b.setAttribute('aria-label', 'Pin the ribbon open'); } } catch (_) {}
document.addEventListener('pointerdown', e => { if (!e.target.closest('#ribbon, .tp-menu')) closeMenus(); }, true);   // (Bars, Boxes and the source colour in the Power menu keep it open)
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenus(); });
/* ---------------- pop-up descriptions ----------------
   Anything with a data-tip shows it in one floating box while the pointer rests on it (or it has the keyboard focus):
   below it, or above it when there is no room below, always inside the window, above the ribbon and the panel. */
const tipBox = document.createElement('div'); tipBox.className = 'tipbox'; tipBox.setAttribute('role', 'tooltip'); tipBox.hidden = true; document.body.append(tipBox);
let tipFor = null, tipTimer = 0;
function showTip(el) {
  tipFor = el; tipBox.textContent = el.dataset.tip; tipBox.hidden = false;
  const r = el.getBoundingClientRect(), b = tipBox.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight, gap = 8;
  let x = Math.min(Math.max(8, r.left), vw - b.width - 8), y = r.bottom + gap;
  if (y + b.height > vh - 8) y = Math.max(8, r.top - gap - b.height);
  tipBox.style.left = x + 'px'; tipBox.style.top = y + 'px';
}
function hideTip() { clearTimeout(tipTimer); tipFor = null; tipBox.hidden = true; }
document.addEventListener('pointerover', e => {
  const el = e.target.closest && e.target.closest('[data-tip]');
  if (el === tipFor) return;
  hideTip();
  if (!el || e.pointerType === 'touch' || document.body.classList.contains('dragging') || !el.dataset.tip) return;
  tipFor = el; tipTimer = setTimeout(() => { if (el.isConnected && tipFor === el) showTip(el); }, 350);
});
document.addEventListener('pointerout', e => { if (tipFor || tipTimer) { const to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('[data-tip]'); if (to !== tipFor) hideTip(); } });
document.addEventListener('pointerdown', hideTip, true);
document.addEventListener('focusin', e => { const el = e.target.closest && e.target.closest('[data-tip]'); if (el && el.matches(':focus-visible')) showTip(el); else hideTip(); });
document.addEventListener('focusout', hideTip);
window.addEventListener('scroll', hideTip, true);
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideTip(); });

/* ---------------- power: the L1 and L2 bars, or supply boxes ----------------
   Each circuit is powered one way or the other (kept with it). With boxes the bars go: wires no longer connect at
   the edges of the sheet, and the L1 Supply and L2 Return boxes on the Home tab feed it instead. */
function showPower() {
  document.querySelectorAll('[data-power]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.power === POWER)));
  document.querySelectorAll('.src-tool').forEach(b => b.hidden = barsOn()); document.getElementById('supply-grp').hidden = barsOn();
  const pm = document.getElementById('pw-menu'); if (!pm.hidden) placeMenu(pm);   // (the Power menu is wider with the supply boxes in it)
  document.querySelectorAll('[data-src]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.src === SRC_COL)));
  PH_COL.forEach((c, i) => { document.documentElement.style.setProperty(`--ph${i + 1}`, c); document.documentElement.style.setProperty(`--ph${i + 1}l`, lighten(c, .45)); });
}
// the source's colour: a swatch for each (see SRC_PAL)
for (const [name, hex] of SRC_PAL) {
  const b = document.createElement('button');
  b.type = 'button'; b.dataset.src = hex; b.style.background = hex; b.setAttribute('aria-label', name + ' source'); b.title = name;
  b.addEventListener('click', () => { if (!editing || hex === SRC_COL) return; snapshot(); SRC_COL = hex; say(`Source colour: ${name}.`); draw(); });
  document.getElementById('src-swatches').appendChild(b);
}
document.querySelectorAll('[data-power]').forEach(b => b.addEventListener('click', () => {
  if (b.dataset.power === POWER || !editing) return;
  snapshot(); POWER = b.dataset.power; normalize(); sel = null;
  say(barsOn() ? 'Powered by the L1 and L2 bars.' : 'Powered by supply boxes: place an L1 Supply and an L2 Return, and wire to their left, right or bottom.');
  fitView(); fit(true); draw();
}));

/* drop-down menus of parts (Buttons, Switches, Outputs, Contacts, Protection, Power): the button drops its parts down under it; picking one (or
   dragging it out onto the panel) places it, as from the ribbon, and closes the menu. A press anywhere else, or Esc,
   closes it too. */
function tpMenu(open, id) {
  for (const box of document.querySelectorAll('.tp-menu')) {
    const btn = document.querySelector(`[aria-controls="${box.id}"]`), on = open && box.id === id;
    if (box.hidden === !on) continue;
    box.hidden = !on; if (btn) btn.setAttribute('aria-expanded', String(on));
    if (on) placeMenu(box);
  }
}
// (under its button, kept inside the window)
function placeMenu(box) { const r = document.querySelector(`[aria-controls="${box.id}"]`).getBoundingClientRect(), w = box.offsetWidth; box.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left)) + 'px'; box.style.top = (r.bottom + 6) + 'px'; }
document.querySelectorAll('[aria-controls]').forEach(b => { const id = b.getAttribute('aria-controls'); if (document.getElementById(id)?.classList.contains('tp-menu')) b.addEventListener('click', () => { if (editing) tpMenu(document.getElementById(id).hidden, id); }); });
document.addEventListener('pointerdown', e => { if (![...document.querySelectorAll('.tp-menu, [aria-controls]')].some(m => m.contains(e.target))) tpMenu(false); }, true);
document.addEventListener('keydown', e => { if (e.key === 'Escape') tpMenu(false); });
window.addEventListener('resize', () => tpMenu(false));
